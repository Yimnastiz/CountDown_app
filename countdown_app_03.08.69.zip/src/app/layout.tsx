import type { Metadata, Viewport } from "next";
import { Chakra_Petch, Silkscreen } from "next/font/google";
import "./globals.css";
const bodyFont = Chakra_Petch({
  subsets: ["latin", "thai"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body",
  display: "swap",
});
const displayFont = Silkscreen({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-display",
  display: "swap",
});
export const metadata: Metadata = {
  title: "Count//Down",
  description: "Personal important-day countdowns",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Count//Down",
  },
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#283828",
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="th" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html:
              "try{var t=localStorage.getItem('countdown-app.settings');var v=t&&JSON.parse(t).theme;if(v&&v!=='system')document.documentElement.dataset.theme=v}catch(e){}",
          }}
        />
      </head>
      <body className={`${bodyFont.variable} ${displayFont.variable}`}>
        {children}
      </body>
    </html>
  );
}
